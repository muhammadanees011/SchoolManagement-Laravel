USE [ePOS-DataTransfer]
GO
/****** Object:  StoredProcedure [dbo].[sp_InsertDataIntoMySQLStaff]    Script Date: 05/02/2024 12:18:22 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Create the stored procedure
ALTER PROCEDURE [dbo].[sp_InsertDataIntoMySQLStaff]
AS
BEGIN
    DECLARE @sql NVARCHAR(MAX)
    DECLARE @linkedServer NVARCHAR(255) = 'MYSQL'; -- Replace with your actual linked server name

    BEGIN TRY
			
		EXECUTE ( 'TRUNCATE TABLE ebStaff' ) AT MYSQL;
		
		INSERT OPENQUERY(MYSQL, 'SELECT  loginID,firstName, surname, UPN, eMail, site, miFareID, created, modified FROM ebStaff')
		SELECT loginID, firstName, surname, UPN, eMail, site, miFareID, CAST(created AS VARCHAR(100)),CAST(modified AS VARCHAR(100))
		FROM ebStaff;
		
    END TRY
    BEGIN CATCH
        -- Handle errors (log, print, or rethrow)
        SELECT ERROR_MESSAGE() AS ErrorMessage;
        -- Rollback the transaction if it's still active
        IF @@TRANCOUNT > 0 ROLLBACK;
    END CATCH
END