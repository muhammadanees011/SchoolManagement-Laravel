USE [ePOS-DataTransfer]
GO
/****** Object:  StoredProcedure [dbo].[sp_InsertDataIntoMySQL]    Script Date: 12/01/2024 6:34:24 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Create the stored procedure
CREATE PROCEDURE [dbo].[sp_InsertDataIntoMySQL]
AS
BEGIN
    DECLARE @sql NVARCHAR(MAX)
    DECLARE @linkedServer NVARCHAR(255) = 'MYSQL'; -- Replace with your actual linked server name

    BEGIN TRY
			
		EXECUTE ( 'TRUNCATE TABLE student_pay.ebStudent' ) AT MYSQL;
		
		INSERT OPENQUERY(MYSQL, 'SELECT remoteID ,loginID, firstName, surname, UPN, eMail, site, miFareID, purseType, fsmAmount, created, modified FROM student_pay.ebStudent')
		SELECT ID,loginID, firstName, surname, UPN, eMail, site, miFareID, purseType, fsmAmount, CAST(created AS VARCHAR(100)),CAST(modified AS VARCHAR(100))
		FROM dbo.ebStudents;
		
    END TRY
    BEGIN CATCH
        -- Handle errors (log, print, or rethrow)
        SELECT ERROR_MESSAGE() AS ErrorMessage;
        -- Rollback the transaction if it's still active
        IF @@TRANCOUNT > 0 ROLLBACK;
    END CATCH
END
GO
